/* 
 * File:   can_rele.h
 * Author: oleksii
 *
 * Created on 30 ??????? 2022 ?., 18:48
 */

#ifndef CAN_RELE_H
#define	CAN_RELE_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* CAN_RELE_H */

