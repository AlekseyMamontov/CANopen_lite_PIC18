/*
 * t1.c
 * 
 * Copyright 2023 Oleksii <oleksii@oleksii-Lenovo-V17-G2-ITL>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */
#include <stdint.h> 
#include <stdio.h>

//#include "CANOPEN.h"

/* structure */


struct map_info{
    
	uint8_t  nbit; 
	uint8_t  sub_index;
	uint16_t index;
    
};
	
struct data_object{
    
    void*       data_object;
    void*       rw_object;
    uint8_t     request_type;
    uint8_t     attribute;
    uint8_t     nbit;
    uint8_t     sub_index;
    uint32_t    sub_index_ff;
    
};

struct OD_object{
    
    uint16_t index;
    void*     data;
    void (*data_func)(struct data_object*);
    
};

struct one_type_array{
    
    uint8_t sub_index;
    void*   array;
    
};

struct record_arr_object{
    
    uint8_t  sub_index;
    uint8_t* nbit;    //arr[subindex] = {0x08,0x20....0x10};
    void*    array[]; //arr[subindex];*uint8,*uint?_t .....
    
};  

struct string_object{
    
    uint8_t*    text;
    uint8_t*    text_buffer;
    uint8_t     n_byte;; 
    uint8_t     cond_sdo;   
};

union map_data{
    
    struct map_info info;
    uint32_t        data32;
    
};

#define MAX_MAP_DATA 8

struct PDO_mapping {
    
    uint8_t           sub_index;
    union map_data    map[MAX_MAP_DATA];
    
    // quick access to the map
    
    struct OD_object* node_map;
    void *            quick_mapping[MAX_MAP_DATA];
  
};

union cond {
    
    struct{
    uint8_t sync       : 1; // sync
    uint8_t new_msg    : 1; // new message rxPDO
    uint8_t timer_event: 1; // 1 - the timer has worked
    uint8_t pause_send : 1; // 1 - pause is over
    uint8_t event_txpdo: 1; // 1 - there is a change to send a message
    uint8_t init_pdo   : 1; // 1 - xPDO init   
    uint8_t rx_tx      : 1; // 0 - rxPDO object, 1 - txPDO
    uint8_t lock       : 1; // 1 - Lock
   }       flag; 
   
    uint8_t stat;
    
};





struct PDO_object{
    
    union cond  cond;
    
    // visible block
    
    uint8_t		sub_index ;
    uint8_t		Transmission_type;
    uint8_t     Sync_start_value;
    
    uint32_t	cob_id ;
    
    uint16_t	Inhibit_time; 	
    uint16_t	Event_timer;
    
    // quick access to the structure map
    
    struct PDO_mapping* pdo_map;
    
    uint8_t     n_byte_pdo_map; // == msg->dlc? map_object_check()
    uint8_t     counter_sync;
    
    // function
    struct func_pdo  *func;
  //void *       node_parent;
    
    // Buffer 
    uint8_t      data[MAX_MAP_DATA];
    
};  

struct func_pdo{
    
    void   (*init_xpdo)(struct PDO_object* pdo);
    void   (*process_map)(struct PDO_object* pdo);
    void   (*process_rxpdo)(struct PDO_object *pdo);
    void   (*process_txpdo)(struct PDO_object *pdo);
    void   (*start_Inhibit_timer)(struct PDO_object *pdo);
    void   (*start_event_timer)(struct PDO_object *pdo);
    
};



struct SDO_object{
	
   
    uint32_t	cob_id_client;
    uint32_t	cob_id_server;
    uint8_t		node_id;
    uint8_t		sub_index;
};

union cob_id{
    
    uint32_t id;
    struct{
           uint8_t     id: 7;
           uint8_t f_code: 4;
           uint8_t       : 5;
           uint8_t       : 8;
           uint8_t       : 5;
           uint8_t frame : 1;
           uint8_t       : 1;
           uint8_t valid : 1;              
            }pdo;     
};

/*  struct msg  */

// for no 8bit
// #pragma pack(push, 1)

typedef union {
    
    struct {
        uint8_t idType;
        uint32_t id;         
        uint8_t dlc;   
        uint8_t data0; 
        uint8_t data1;
        uint8_t data2; 
        uint8_t data3; 
        uint8_t data4; 
        uint8_t data5; 
        uint8_t data6; 
        uint8_t data7; 
    } can_frame;
    
   
    
    struct {
        uint8_t  idType; 
        union {
            uint32_t id;
          struct{
            uint16_t func_id;
            uint8_t  none;
            uint8_t  status;
                 }       _id;
          struct{
            uint8_t id_node: 7;
            uint8_t  func: 4;
            uint8_t      : 5;
            uint8_t      : 8;
            uint8_t      : 5;
            uint8_t  ext : 1;
            uint8_t      : 1;
            uint8_t  lock: 1;                                
                 }      bit_id;        
              }  cob;	   
        uint8_t  dlc;	  
        uint8_t data0; 
        uint8_t data1;
        uint8_t data2; 
        uint8_t data3; 
        uint8_t data4; 
        uint8_t data5; 
        uint8_t data6; 
        uint8_t data7;  			
    }frame_pdo;
    
    uint8_t array[14];
    
}CanOpen_msg;

//  for no 8bit
//  #pragma pack(pop) 

#define COB_ID      array[1]&0x7f

#define MAX_PDO_OBJECT 8 //4x2

struct xCanOpen{

    uint8_t                  id; /*id */
    uint8_t                mode; /*pre-orintal etc.*/

    CanOpen_msg*    current_msg;

    uint8_t  (*init)(uint8_t id);
    uint8_t  (*receiving_message)(CanOpen_msg *msg);
    uint8_t  (*sending_message)(CanOpen_msg *msg);

    struct OD_object*   map;
    
    struct PDO_object*  pdo[MAX_PDO_OBJECT];
    struct SDO_object*  sdo[1];

};

const 
uint32_t

/* 401d (0x191) | 16th Bit Digital input | 17th Bit Digital output */

 N1000_Device_Type = 30191,
 N1008_Device_name = 0,
 N1009_Hard_version = 0,
 N100A_Soft_version = 0;





 /* DS-401*/   
    
 uint8_t  
        
 // 0 - port B, 1 - port C
        
 output_port[2]    ={0x00,0x00},//6200h
 polary_output[2]  ={0x00,0x00},//6202h
 filter_output[2]    ={0xFF,0xFF},//6208h
        
 // AC220V portA.5 
        
 input_port[1]   = {0},  //6000h
 polary_input[1] = {0},  //6002h
 filter_input[1] = {0};  //6003h 


 struct one_type_array
 
 N6200_output = { .sub_index = 2, .array =output_port },
 N6202_output = { .sub_index = 2, .array =polary_output},
 N6208_output = { .sub_index = 2, .array =filter_output},
         
 N6000_input = { .sub_index = 1, .array = input_port},
 N6002_input = { .sub_index = 1, .array = polary_input},
 N6003_input = { .sub_index = 1, .array = filter_input};        
         

// Error

uint8_t  N1001_Error_register = 0;   
uint32_t data_error[8];
struct 
one_type_array 
N1003_Error = { .sub_index = 5, .array = data_error };

 
// OD_table
struct OD_object OD_Triac_rele[15]={

    //{.index. .data, .func_data },
    
    {0x1000,(void*)&N1000_Device_Type,   NULL},
    {0x1001,(void*)&N1001_Error_register,NULL},
    {0x1003,(void*)&N1003_Error,         NULL},
    {0x1008,(void*)&N1008_Device_name,   NULL},
    {0x1009,(void*)&N1009_Hard_version,  NULL},
    {0x100A,(void*)&N100A_Soft_version,  NULL},
    
    {0x6000,(void*)&N6000_input, NULL},
    {0x6002,(void*)&N6002_input, NULL},
    {0x6003,(void*)&N6003_input, NULL},    
       
    {0x6200,(void*)&N6200_output, NULL},
    {0x6202,(void*)&N6202_output, NULL},
    {0x6208,(void*)&N6208_output, NULL},

    {0xffff,NULL,NULL},
        
};

 











/******************* PDO objects ***************
 struct PDO_object{
    
    union cond  cond;
    
    // visible block
    
    uint8_t		sub_index ;
    uint8_t		Transmission_type;
    uint8_t     Sync_start_value;
    
    uint32_t	cob_id ;
    
    uint16_t	Inhibit_time; 	
    uint16_t	Event_timer;
    
    // quick access to the structure map
    
    struct PDO_mapping* pdo_map;
    
    uint8_t     n_byte_pdo_map; // == msg->dlc? map_object_check()
    uint8_t     counter_sync;
    
    // function
    struct func_pdo  *func;
  //void *       node_parent;
    
    // Buffer 
    uint8_t      data[MAX_MAP_DATA];
    
};  
 
 struct PDO_mapping {
    
    uint8_t           sub_index;
    union map_data    map[MAX_MAP_DATA];
    // quick access to the map
    void *            quick_mapping[MAX_MAP_DATA];
    struct OD_object* node_map;
    
};
 
 
 
 **/ 
 
/* rxPDO1  */

struct PDO_mapping map_rxpdo1 = {

    .sub_index = 1,

    
    //.node_map = &OD_Triac_rele,


};




struct PDO_object rx_pdo1={

    .cond = 0,
    .Transmission_type = 0xFF,
    .cob_id = 0x200,
    .sub_index = 5,
    .pdo_map = &map_rxpdo1,

};







struct PDO_object tx_pdo1={


};

struct SDO_object sdo_rx_tx;   
    
    
struct xCanOpen Triac_rele = {
.pdo = {
        &rx_pdo1,// 180 + cob_id
        &tx_pdo1,// 200 + cob_id
        },
       
.sdo = {&sdo_rx_tx},
.map = OD_Triac_rele,
};    
 
     
    
    
    
    
    
    


int main(int argc, char **argv)
{
	
	return 0;
}

